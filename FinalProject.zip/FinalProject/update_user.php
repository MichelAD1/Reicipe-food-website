<?php
$country=$_POST['country'];
$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$username=$_POST['username'];
$phone_number=$_POST['phone_number'];
$email=$_POST['email'];
$password=$_POST['password'];
$password=hash('sha256',$password);
$db_database="food_recipesdb"; //name of database

$conn=new mysqli('localhost','root','','food_recipesdb');


if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $stmt=$conn->prepare("UPDATE customers SET first_name=?, last_name=?,email=?,phone_number=?,username=?,password=?,country=? WHERE email='$email'");
    $stmt->bind_param("sssisss",$first_name,$last_name,$email,$phone_number,$username,$password,$country);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}
header("Location:index.html");
?>