<?php
session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="css/dropdown.css" rel="stylesheet" />
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Delicious - Food Recipes | Upload Your Recipe</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <i class="circle-preloader"></i>
        <img src="img/core-img/salad.png" alt="">
    </div>


    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
        <div class="action">
            <div class="profile" onclick="menuToggle();">
              <img src="img\icon.png" />
            </div>
            <div class="menu">
              <h3><?php echo($_SESSION['username']) ?><br /></h3>
              <ul>
                <li>
                  <img src="img\core-img\user.png" /><a href="my_profile.php">My profile</a>
                </li>
                <li>
                  <img src="img\core-img\logout.png" /><a href="index.html">Logout</a>
                </li>
              </ul>
            </div>
          </div>
          <script>
            function menuToggle() {
              const toggleMenu = document.querySelector(".menu");
              toggleMenu.classList.toggle("active");
            }
          </script>
        </div>
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-between">
                    <!-- Breaking News -->
                    <div class="col-12 col-sm-6">
                        <div class="breaking-news">
                            <div id="breakingNewsTicker" class="ticker">
                                <ul>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Navbar Area -->
        <div class="delicious-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="deliciousNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.html"><img src="img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li class="active"><a href="index_user.php">Home</a></li>
                                    <li><a href="signup.php">Sign Up</a></li>
                                    <li><a href="signin.php">Log in</a></li>
                                    <li><a href="recipes.php">Recipes</a></li>
                                    <li><a href="books.php">Shop</a></li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/breadcumb5.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-text text-center">
                        <h2><?php
                            if (!empty($_SESSION['invalid_email_to'])){
                            
	                            echo $_SESSION['invalid_email_to']; 
                                unset($_SESSION['invalid_email_to']);
                            }else{
                                echo"Create A Book";
                            }
    
                            ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->
    <div class="receipe-post-area section-padding-80">
                <div class="row" style = "position:relative; left:80px; top:2px;">
                    <div class="col-12">
                        <div class="section-heading text-left">
                            <h3>Book Details</h3>
                        </div>
                    </div>
                </div>

                <div class="row" style = "position:relative; left:80px; top:2px;">
                    <div class="col-12">
                        <div class="contact-form-area">
                            <form action="add_book.php" method="post" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-12 col-lg-5">
                                        <input type="text" class="form-control" name="title" placeholder="Book Title" required=""> 
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <input type="text" class="form-control" name="author_name" placeholder="Author Name" required=""> 
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <input type="double" class="form-control" name="price" placeholder="Price" required=""> 
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <input type="email" class="form-control" name="cust_email" placeholder="Email - This information will not be displayed with the recipe." required="">
                                    </div>
                                    <div>
                                        <div class="col-12 col-lg-11">
    
                                        <label for="formFileMultiple" class="form-label">Upload Book Image</label>
                                        <input type="file" name="image"  accept="image/*">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-4">
                                <ul>
                                    <br>
                                    <br>
                                    <li class="active"><input type="submit" name="submit" value="Create Book"></li>
                                </ul>
                                </div>

                           </form>
                       </div>
                    </div>
                </div>     
    </div>    
    <footer class="footer-area">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-12 h-100 d-flex flex-wrap align-items-center justify-content-between">
                    <!-- Footer Logo -->
                    <div class="footer-logo">
                        <a href="#"><img src="img/core-img/logo.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>