<?php
session_start(); ?>

<!DOCTYPE html>
<head>
	<link rel="stylesheet" href="css/signup-in.css">
	<title>My Profile | Delicious</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script
		type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- Custom Theme files -->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="icon" href="img/core-img/favicon.ico">
	<!-- //Custom Theme files -->
	<!-- web font -->
	<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
	<!-- //web font -->
	<!-- Favicon -->
	
</head>

<body>

   <div class="main-w3layouts wrapper">
		<h1>My Profile</h1>
		<div class="main-agileinfo">
		<div class="agileits-top">
        <form action="update_user.php" method="post">

        <input class="text" type="text" name="first_name" placeholder="<?php echo($_SESSION['first_name']) ?>" required="">
        <br>
		<br>
        <input class="text" type="text" name="last_name" placeholder="<?php echo($_SESSION['last_name']) ?>" required="">
        <br>
		<br>
        <input class="text" type="text" name="username" placeholder=<?php echo($_SESSION['username']) ?> required="">
        <br>
		
        <input class="text email" type="email" name="email" placeholder=<?php echo($_SESSION['email']) ?> required="">
        <br>
		
        <input class="text" type="text" name="country" placeholder=<?php echo($_SESSION['country']) ?> required="">
        <br>
		<br>
        <input type="number" name="phone_number" placeholder=<?php echo($_SESSION['phone_number']) ?> required="">
        <br>
		<br>
        <input class="text" type="password" name="password" placeholder="New Password" required="">
        <br>
        <input type="submit" value="DONE">
       </form>
       </div>
       </div>
   </div>
        
</body>
</html>