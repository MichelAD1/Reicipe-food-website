
<?php
session_start(); 
$recipe_title=$_POST['recipe_title'];
$db_database="food_recipesdb"; //name of database

$conn=new mysqli('localhost','root','','food_recipesdb');
$sql= $conn->prepare("SELECT COUNT(*) from recipes WHERE recipe_title=?");
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $sql->bind_param("s",$recipe_title);
    $sql->execute();
    $sql->bind_result($result);
    $sql->fetch();

    if($result==0){
        $_SESSION['error_recipe'] = 'No Such Recipe With The Given Title';
        header("Location:nosuch_recipe.php");
        
    }else{
        $sql ="SELECT * FROM recipes WHERE recipe_title='$recipe_title'";
        $result_r = mysqli_query($conn,$sql);
    }
    
    $conn->close();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="css/dropdown.css" rel="stylesheet" />
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Delicious - Food Recipes | Recipe Post</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <i class="circle-preloader"></i>
        <img src="img/core-img/salad.png" alt="">
    </div>


    <!-- ##### Header Area Start ##### -->
    <header class="header-area">
    <div class="action">
            <div class="profile" onclick="menuToggle();">
              <img src="img\icon.png" />
            </div>
            <div class="menu">
              <h3><?php echo($_SESSION['username']) ?><br /></h3>
              <ul>
                <li>
                  <img src="img\core-img\user.png" /><a href="my_profile.php">My profile</a>
                </li>
                <li>
                  <img src="img\core-img\logout.png" /><a href="index.html">Logout</a>
                </li>
              </ul>
            </div>
          </div>
          <script>
            function menuToggle() {
              const toggleMenu = document.querySelector(".menu");
              toggleMenu.classList.toggle("active");
            }
          </script>
        </div>
        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-between">
                    <!-- Breaking News -->
                    <div class="col-12 col-sm-6">
                        <div class="breaking-news">
                            <div id="breakingNewsTicker" class="ticker">
                                <ul>
                                    <li><a href="upload_recipe.php">You can submit your own recipes!</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navbar Area -->
        <div class="delicious-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="deliciousNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.html"><img src="img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- close btn -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul>
                                    <li class="active"><a href="index_user.php">Home</a></li>
                                    <li><a href="signup.php">Sign Up</a></li>
                                    <li><a href="signin.php">Log in</a></li>
                                    <li><a href="recipes.php">Recipes</a></li>
                                    <li><a href="books.php">Shop</a></li>
                                </ul>
                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/breadcumb3.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-text text-center">
                        <h2>Recipes</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->
    <!-- Receipe Slider -->
    <center>
        
    <?php
    while($rows=mysqli_fetch_assoc($result_r)){
    ?>
     <br>
                            <br>
    <style>
                                    h5{text-align: left;
                                    width=20%;
                                margin-left:100px;
                                padding-left:100px;
                            float up;}
                                </style>
                            <h5>Meal Type: <?php echo $rows['meal_type']?> </h5>
                            <br>
                            <h5>Diet: <?php echo $rows['diet']?> </h5>
    
    <?php echo"<img src='img/bg-img/".$rows['image']. "'style='width:30%;height:30%;';>";?>
    
    
    <div class="container">
            <div class="row">
                <div class="col-12 ">
                        <br>
                        <h2>
                            <?php echo $rows['recipe_title']?>
                        </h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Receipe Content Area -->
        <div class="w3-row w3-padding-64" id="menu">
        <div class="w3-col l6 w3-padding-large">
                                <br>
                                <h6 >Preperation Time: <?php echo $rows['preperation_time']?> minute(s)</h6>
                                <h6>Number of Servings: <?php echo $rows['num_of_servings']?> Serving(s)</h6>
                            
                            <br>
                            <br>
                            <br>
                            <h4>Ingredients: </h4>
                            <br>

                            <!-- Custom Checkbox -->
                            <!-- <div class="custom-control custom-checkbox"> -->
                                <p>
                               
                                <?php 
                                $text = trim( $rows['ingredients']);
                                $textAr = explode("\n", $text);
                                $textAr = array_filter($textAr, 'trim'); 
                                
                                foreach ($textAr as $line) {
                                    echo "- ",$line,"<br>";
                                
                                }
                                ?>
                                </p> 
                        
                                 
                        </div>
                    <!-- Ingredients -->
                    <!-- <div class="col-12 col-lg-8">
                        <div class="ingredients"> -->
                        <br>
                                <br>
                                <h4>Directions: </h4>
                        <br>
                        
                        <p>
                        <?php 
                                $text = trim($rows['directions']);
                                $textAr = explode("\n", $text);
                                $textAr = array_filter($textAr, 'trim');
                                $count=0; 
                                
                                foreach ($textAr as $line) {
                                    $count++;
                                    echo $count,"- ",$line,"<br>" ;
                            
                                }?>
                                </p>
                                <br>
                                <br>
                                <br>
                                
                            <br>
                            <br>
                            <br><br>
                           
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
    



    <?php
    }
    ?>
    </center>         
    
    <div>
        <style>
            .img-container {
              text-align: center;
            }
          </style>
          <div class="img-container"> <!-- Block parent element -->
            <img src="img\core-img\logo2.png">
            <div class="col-12">
            <button class="btn delicious-btn mt-30" type="submit"><a href="upload_recipe.php">Click here</a></button>
            </div>
          </div>
          
    </div>
    
    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area">
        <div class="container h-100">
            <div class="row h-100">
                <div class="col-12 h-100 d-flex flex-wrap align-items-center justify-content-between">
                    <!-- Footer Logo -->
                    <div class="footer-logo">
                        <a href="index.html"><img src="img/core-img/logo.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area Start ##### -->

    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
</body>

</html>
