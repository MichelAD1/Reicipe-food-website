<?php
session_start();

$db_database="food_recipesdb"; //name of database
$target="img/bg-img/".basename($_FILES['image']['name']);
$conn=new mysqli('localhost','root','','food_recipesdb');
$conn1=new mysqli('localhost','root','','food_recipesdb');
$sql= $conn->prepare("SELECT COUNT(*) from recipes WHERE cust_email=?");
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    
    $title=$_POST['title'];
    $author_name=$_POST['author_name'];
    $price=$_POST['price'];
    $image=$_FILES['image']['name'];
    $cust_email=$_POST['cust_email'];
    $sql->bind_param("s",$cust_email);
    $sql->execute();
    $sql->bind_result($result);
    $sql->fetch();
    if($result==0){
        $_SESSION['error_recipe'] = "You Did Not Create Any Recipe To Have A Book";
        header("Location:nosuch_recipe.php");
    }else{
        if($cust_email==$_SESSION['email']){
            $stmt=$conn1->prepare("insert into books(title,author_name,image,price,cust_email)
            values(?,?,?,?,?)");
            $stmt->bind_param("sssds",$title,$author_name,$image,$price,$cust_email);
            $stmt->execute();
        
            $stmt=$conn1->prepare("insert into recipes_in_book(books_id,recipes_id)
            select b.id, r.id from books as b, recipes as r where b.cust_email=r.cust_email and r.cust_email='$cust_email' and b.id = (select id from books order by id desc limit 1);");
            $stmt->execute();
            $stmt->close();
            $conn->close();
            header("Location:index_user.php");
    
        }else{
            $_SESSION['invalid_email_to']="Email Inserted Does Not Correspond With Your Email";
            header("Location:create_books.php");
        }
    }
    
}
?>