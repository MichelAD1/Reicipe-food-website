<?php

session_start(); 
$recipe_title=$_POST['recipe_title'];
$tmp_email=$_SESSION['email'];
$db_database="food_recipesdb"; //name of database

$conn=new mysqli('localhost','root','','food_recipesdb');
$conn1=new mysqli('localhost','root','','food_recipesdb');
$sql= $conn->prepare("SELECT COUNT(*) from recipes WHERE recipe_title=? AND cust_email=?");
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $sql->bind_param("ss",$recipe_title,$tmp_email);
    $sql->execute();
    $sql->bind_result($result);
    $sql->fetch();

    if($result==0){
        $_SESSION['error_recipe'] = "You Don't Have Such Recipe With The Given Title";
        header("Location:nosuch_recipe.php");
        
    }else{
        $sql ="SELECT * FROM recipes WHERE recipe_title='$recipe_title' and cust_email='$tmp_email'";
        $result_r = mysqli_query($conn,$sql);
        while($rows=mysqli_fetch_assoc($result_r)){
            if($rows['recipe_title']=$recipe_title AND $rows['cust_email']=$tmp_email ){
                $stmt=$conn1->prepare("DELETE FROM recipes WHERE recipe_title=? AND cust_email=? limit 1");
                $stmt->bind_param("ss",$recipe_title,$_SESSION['email']);
                $stmt->execute();
                $tmp_id=$rows['id'];
                $stmt=$conn1->prepare("DELETE FROM recipe_creator WHERE recipes_id=?");
                $stmt->bind_param("i",$tmp_id);
                $stmt->execute();
                break;
                
            }
            
        }
        header("Location:index_user.php");
    }
    
    
    $conn->close();
    
    
}


?>