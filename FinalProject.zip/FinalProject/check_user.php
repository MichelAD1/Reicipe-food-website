<?php
session_start();
$email=$_POST['email'];
$password=$_POST['password'];
$password=hash('sha256',$password);
$db_database="food_recipesdb"; //name of database

$conn=new mysqli('localhost','root','','food_recipesdb');
$conn1=new mysqli('localhost','root','','food_recipesdb');

$sql= $conn->prepare("SELECT COUNT(*) from customers WHERE password=? and email=?");



if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $sql->bind_param("ss",$password,$email);
    $sql->execute();
    $sql->bind_result($result);
    $sql->fetch();
    

    if($result==0){
        $_SESSION['error'] = 'Incorrect email and password combination, try again';
        header("Location:signin.php");
        
    }else{
        $sql = $conn1->query("SELECT id,first_name,last_name,username,country,email,phone_number FROM customers WHERE email='$email' AND password='$password'");
        $obj = $sql -> fetch_object();
        $_SESSION['id']=$obj->id;
        $_SESSION['first_name'] = $obj->first_name;
        $_SESSION['last_name'] = $obj->last_name;
        $_SESSION['username'] = $obj->username;
        $_SESSION['country'] = $obj->country;
        $_SESSION['email'] = $obj->email;
        $_SESSION['phone_number'] = $obj->phone_number;
        header("Location:index_user.php");
        
       
    }
    $stmt->close();
    $conn->close();
}

?>