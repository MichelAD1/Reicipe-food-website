<?php
session_start();

$db_database="food_recipesdb"; //name of database

if(isset($_POST['submit'])){
    $target="img/bg-img/".basename($_FILES['image']['name']);
    $conn=new mysqli('localhost','root','','food_recipesdb');
    if($conn->connect_error){
        die('Connection Failed : '.$conn->connect_error);
        header("Location:recipes.php");
    }else{
        $cust_email=$_POST['cust_email'];
        $image=$_FILES['image']['name'];
        $recipe_title=$_POST['recipe_title'];
        $num_of_servings=$_POST['num_of_servings'];
        $preperation_time=$_POST['preperation_time'];
        $ingredients=$_POST['ingredients'];
        $directions=$_POST['directions'];
        $meal_type=$_POST['meal_type'];
        $diet=$_POST['diet'];
        if($cust_email==$_SESSION['email']){
            $stmt=$conn->prepare("INSERT INTO recipes(image,ingredients,recipe_title,num_of_servings,directions,preperation_time,meal_type,diet,cust_email)
        values(?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssisisss",$image,$ingredients,$recipe_title,$num_of_servings,$directions,$preperation_time,$meal_type,$diet,$cust_email);
        $stmt->execute();

        $stmt=$conn->prepare("insert into recipe_creator(customers_id,recipes_id)
        select c.id, r.id from customers as c, recipes as r WHERE c.email= r.cust_email ORDER BY r.id DESC LIMIT 1;");
        $stmt->execute();
        $stmt->close();
        $conn->close();
        header("Location:index_user.php");

        }else{
            $_SESSION['invalid_email']="Email Inserted Does Not Correspond With Your Email";
            header("Location:upload_recipe.php");
        }

        
    }
    
}


?>

