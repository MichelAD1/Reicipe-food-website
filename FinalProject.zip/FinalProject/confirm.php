<?php
session_start();

$db_database="food_recipesdb"; //name of database
$title=$_POST['title'];
$ammount_purchased=$_POST['ammount_purchased'];

$conn=new mysqli('localhost','root','','food_recipesdb');
$conn1=new mysqli('localhost','root','','food_recipesdb');
$conn2=new mysqli('localhost','root','','food_recipesdb');
$sql= $conn->prepare("SELECT COUNT(*) from books WHERE title=?");
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $sql->bind_param("s",$title);
    $sql->execute();
    $sql->bind_result($result);
    $sql->fetch();

    if($result==0){
        $_SESSION['error_recipe'] = "There Are No Books With The Given Title";
        header("Location:nosuch_recipe.php");
        
    }else{
        $sql ="SELECT * FROM books WHERE title='$title'";
        $result_b = mysqli_query($conn,$sql);
        while($rows=mysqli_fetch_assoc($result_b)){
            if($rows['title']=$title){
                $stmt=$conn1->prepare("INSERT INTO orders (customers_id,books_id) values(?,?)");
                $tmp_id_c=$_SESSION['id'];
                $tmp_id_b=$rows['id'];
                $tmp_price=$rows['price'];
                $stmt->bind_param("ii",$tmp_id_c,$tmp_id_b);
                $stmt->execute();
                
                $stmt1=$conn1->prepare("SELECT id FROM orders WHERE customers_id=? and books_id=?");
                $stmt1->bind_param("ii",$tmp_id_c,$tmp_id_b);
                $stmt1->execute();
                $stmt1->bind_result($result_o);
                $stmt1->fetch();

                date_default_timezone_set('GMT');
                $date = date('Y-m-d');
                $stmt2=$conn2->prepare("INSERT INTO order_details (ammount_purchased,orders_id,total_price,date) values(?,?,?,?)");
                $total_price=number_format($tmp_price*$ammount_purchased);
                $stmt2->bind_param("iids",$ammount_purchased,$result_o,$total_price,$date);
                $stmt2->execute();
                break;
            }
            
        }
        header("Location:index_user.php");
    }
    
    
    $conn->close();
    
    
}
?>